# MAC420
Autor: 11585716 - Débora Emilli Costa Oliveira

Modelo 1 foi implementado na classe Sphere.py
Normais e coordenadas (u, v) de textura do Modelo 1 foram calculadas na classe Sphere.py
Modelo 2 foi implementado na classe SphereTessellation.py
Normais e coordenadas (u, v) de textura do Modelo 2 foram calculadas na classe Shaders.py na etapa de Tessellation
Evaluation Shader


Os parâmetros de raio e de número de amostras tanto do modelo 1 quanto do modelo 2 podem ser alterados na interface.

Para executar, no terminal, escreva python3 main.py
